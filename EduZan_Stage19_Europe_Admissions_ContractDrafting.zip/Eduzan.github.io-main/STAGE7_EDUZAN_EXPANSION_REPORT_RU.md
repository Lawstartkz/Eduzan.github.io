# EduZan — Stage 7: Legal English, Kazakh legal catalogue and European English-taught law programmes

**Date:** 23 November 2026  
**Base:** `EduZan_KK_Catalog_Stage6_preserve_52_universities.zip`  
**Status:** local working archive only; no GitHub push or publication.

## 1. Work completed

### A. Legal English — expanded applied curriculum

Files changed:
- `legal-english.html`
- `kz/kz-legal-english.html`
- `index.html` (site-wide search/navigation entry)

Added a new `le-advanced` applied-learning section in the Russian and Kazakh Legal English pages. It does not replace or duplicate the existing four-level interactive course. The new section adds six practice tracks:
1. Legal systems and sources of law;
2. Public International Law;
3. Commercial and Investment Law;
4. Corporate, Banking and Compliance;
5. Arbitration and Dispute Resolution;
6. Legal Research and Writing.

Added an original hypothetical supply-contract case on late delivery and an export restriction, with tasks for identifying issues, checking clauses and writing a short preliminary memo. The text expressly warns that the case is a language exercise, not legal advice.

### B. Kazakh legal university names, programmes and disciplines

File changed:
- `kz/kz-catalog.html`

Added a source-backed section for official Kazakh programme and discipline titles from three universities:

**Халел Досмұхамедұлы атындағы Атырау университеті**
- Four currently listed legal bachelor programmes, reproduced from the university's Kazakh admissions page.
- Twenty-two published law-course titles reproduced from the Civil Law Department's official Kazakh page. The page links the listed courses to programmes 6B04201 and 6B04204; the EduZan page warns that this is not a complete curriculum for every programme or year.

**М. Әуезов атындағы Оңтүстік Қазақстан университеті**
- Five programme names and four department names reproduced from the Law Faculty's official Kazakh page.
- No full list of course titles was added because a current, complete official course catalogue was not verified in the material used for this stage.

**Әл-Фараби атындағы Қазақ ұлттық университеті**
- Nineteen legal discipline titles selected from the official Kazakh 6B04205 programme page and its published study plan.
- The page labels them as examples from the official study plan, not as a full transcript or permanent list.

The existing 52-university registry was not re-audited or edited. `kz/universities_kk_names.json`, the 52-row CSV and XLSX were preserved. No unverified university/programme names were independently translated.

### C. Law in Europe — expanded official English-taught programme catalogue

Files changed:
- `law-in-europe.html`
- `kz/kz-law-in-europe.html`

Added six programmes with official university pages confirming programme level and English-language delivery:

**Bachelor's level (Italy)**
- University of Trento — Comparative, European and International Legal Studies (CEILS), 3 years, 180 ECTS, entirely in English.
- University of Macerata — International, European and Comparative Legal Studies (IECoLS), 3-year bachelor, English.
- University of Messina — Transnational and European Legal Studies, 3-year law bachelor, 180 ECTS, entirely in English; B2 English requirement stated by the university.

**Master's level (Italy)**
- University of Bologna — Law, Economics and Governance, 2 years, 120 ECTS, entirely in English; classified as an interdisciplinary Law/Economics degree, not described as a classic LL.M.
- University of Trento — Global Law Making, 2 years, 120 ECTS, English.
- University of Milan — Law and Sustainable Development, LL.M., 2 years, 120 ECTS, entirely in English.

The new cards preserve official programme titles in English and provide Kazakh/Russian explanations. They distinguish a Law Degree from a Law-related Degree and do not claim that an academic degree automatically grants access to a regulated legal profession.

## 2. Official source register

Kazakhstan:
- Atyrau University, 2026–27 bachelor programmes: https://atyrau.edu.kz/kz/Home/Bachelor
- Atyrau University, law disciplines published by the Civil Law Department: https://atyrau.edu.kz/kz/Information/Info/1375?name=University+projects
- Auezov University, Law Faculty: https://auezov.edu.kz/kaz/fac-um.html
- Al-Farabi KazNU, 6B04205 Law programme and curriculum: https://www.farabi.university/programs/1562?lang=kz

Europe:
- University of Trento CEILS: https://corsi.unitn.it/en/comparative-european-and-international-legal-studies
- University of Macerata IECoLS: https://corsi.unimc.it/en/iecols
- University of Messina TELS 2026/27: https://giurisprudenza.unime.it/en/node/903
- University of Bologna Law, Economics and Governance 2026/27: https://www.unibo.it/en/study/second-cycle-degree/programme/2026/6829
- University of Trento Global Law Making: https://corsi.unitn.it/en/global-law-making
- University of Milan Law and Sustainable Development 2026/27: https://llmsd.cdl.unimi.it/en/ugovcdl/of/cdsi20270000abaof2

## 3. Files changed

1. `legal-english.html`
2. `kz/kz-legal-english.html`
3. `index.html`
4. `law-in-europe.html`
5. `kz/kz-law-in-europe.html`
6. `kz/kz-catalog.html`
7. `STAGE7_EDUZAN_EXPANSION_REPORT_RU.md` (this report)

## 4. Verification performed

- `node --check lawstart-legal-english.js` — passed; existing interactive four-level course was not edited.
- `node --check kz/kz-lawstart-catalog-kk.js` — passed; catalogue data script was not edited.
- JSON registry parses and contains 52 university records; `_meta.count` remains 52.
- CSV registry contains 52 data rows.
- Static HTML check: no duplicate IDs in the six changed HTML pages.
- Static local-link and in-page anchor check: no broken local targets or missing in-page anchors in the six changed HTML pages.
- Programme/course names in the new Kazakhstan block are directly reproduced from the linked official Kazakh university pages; no machine-generated translation was used for university-specific names.
- No browser visual/runtime test was performed in this stage. Visual appearance and live website rendering remain unverified.
- GitHub was not changed; these changes are not live.

## 5. Limits and next work

- The Kazakhstan discipline block is an initial verified subset, not a complete discipline list for all 52 universities. Expand it university by university only when an official Kazakh course catalogue or study plan is available.
- Some official university pages show curricula that may change by academic year. EduZan identifies them as examples and links to the source.
- The Europe catalogue remains a verified selection, not a complete list of all European English-taught law programmes. Recheck admissions, tuition and deadlines for each intake before presenting them as current.
- Legal English now has six additional applied tracks, but these are self-study materials; no new automated assessment engine or AI tutor has been added.
