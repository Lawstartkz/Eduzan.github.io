# EduZan — Stage 17: Europe catalogue and Kazakhstan master's classification

## Completed

1. Expanded `law-in-europe.html` from eight to ten country sections by adding Latvia and Cyprus.
2. Added two English-taught Riga Graduate School of Law bachelor programmes: Law and Business (LL.B.) and Law and Diplomacy (LL.B.), each 3 years / 183 ECTS. The awarded degree descriptions are preserved as stated by RGSL.
3. Added RGSL master's routes: Business Law and Finance (1 year / 60 ECTS), its separate 2-year / 120 ECTS route, and Technology Law (1 year / 60 ECTS). Entry-field and 240-ECTS restrictions are explicitly described; no claim that any non-law applicant is automatically eligible.
4. Added two Cyprus English-taught LLB programmes: UCLan Cyprus (4 years / 240 ECTS; Cyprus Legal Council recognition stated by provider) and University of Limassol (4 years / 240 ECTS; CYQAA/KYSATS recognition stated by provider). Professional practice is kept separate from academic degree recognition.
5. Updated country count, quick navigation, meta description, and method framing.
6. Clarified Kostanay Regional University master's tracks in `kz/kz-catalog.html`: 7M04201 (2 years) is labelled scientific-pedagogical and 7M04202 (1 year) profile, based on the university's Kazakh-language rule that scientific-pedagogical master's programmes are at least 2 years and profile programmes at least 1 year. The page now links directly to the official Kazakh master's page.
7. Carried the Stage 16 cumulative discipline CSV forward unchanged. No new course titles were added in this stage.

## Official sources

- RGSL Law and Business: https://www.rgsl.edu.lv/programmes/law-and-business
- RGSL Law and Diplomacy: https://www.rgsl.edu.lv/programmes/law-and-diplomacy
- RGSL Business Law and Finance: https://www.rgsl.edu.lv/programmes/law-and-finance-%C2%A0
- RGSL Business Law and Finance (2 years): https://www.rgsl.edu.lv/programmes/law-and-finance-2-years
- RGSL Technology Law: https://www.rgsl.edu.lv/programmes/technology-law
- RGSL 2027 admissions announcement (20 Nov 2026): https://www.rgsl.edu.lv/news-and-events/news/applications-now-open-for-bachelors-and-masters-programmes
- UCLan Cyprus LLB: https://www.uclancyprus.ac.cy/undergraduate-course/bachelor-of-laws-llb-hons/
- University of Limassol LLB: https://www.uol.ac.cy/en/study/llb/
- KRU official Kazakh master's page: https://ksu.edu.kz/kz/educational-activity/obrazovatelnye-programmy/magistratura/
- KRU 6B04201 2026–2027 elective catalogue: https://ksu.edu.kz/files/educational-program/ked/ked-6b04201-26-27.pdf
- KRU 6B04203 2026–2027 elective catalogue: https://ksu.edu.kz/files/educational-program/ked/ked-6b04203-26-27.pdf

## Limits / verification

- This is an expansion of a verified selection, not an exhaustive European inventory.
- Fees and admission deadlines are cycle-specific; verify again before applying.
- Professional admission to legal practice is not inferred from academic degree names.
- KRU master's classification follows the university's published general duration rule applied to the two named programmes; if a programme-specific document later states a different track, that document should supersede this inference.
- No changes were made to the 52-university verified-name registry files.
- GitHub was not changed; no publication or push was performed.
- Browser visual testing was not performed.
