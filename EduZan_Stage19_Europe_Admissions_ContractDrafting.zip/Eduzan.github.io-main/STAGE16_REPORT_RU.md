# EduZan — Stage 16: Legal English, Kazakhstan legal terminology and Europe catalogue

## Completed in this local stage

1. Expanded `legal-english.html` with a trilingual Kazakhstan Constitution reading module, a terminology comparison table, practical tasks, and links to international/EU primary-law and case-law databases.
2. Clearly labelled the English Constitution text on Adilet as an **unofficial translation**. Kazakh and Russian text links are provided separately; the exercise is for language learning, not legal advice or an approved trilingual glossary.
3. Added a six-week Legal English self-study pathway with weekly themes and practical outputs.
4. Expanded `law-in-europe.html` from six to eight country sections by adding verified English-taught Law bachelor programmes at Tallinn University (Estonia) and Aristotle University of Thessaloniki (Greece).
5. Added the official 2026–2029 University of Messina teaching-plan PDF. The published curriculum confirms Legal English (6 ECTS / 36 hours) in year one and lists the other law modules.
6. Tightened the Groningen note: its English International and European Law bachelor does not meet the Dutch civiel effect requirements for direct progression to lawyer/judge professions.
7. Added one Kazakh discipline title to the cumulative register: `Аумақтар мен басқа кеңістіктердің халықаралық құқықтық режимі`, directly visible in ENU's official Kazakh programme-change page for 2024–2025. No other ambiguous titles were normalised or guessed.
8. Updated the ENU card to distinguish this single change-log title from the full elective-course catalogue, which remains inaccessible due to repeated PDF timeouts.
9. Updated the Kazakh Europe page's overview wording and added a link to the expanded catalogue without inventing Kazakh translations of programme or qualification names.

## Official sources used

- ENU Kazakh programme/change page: https://fl.enu.kz/kz/page/departments/international-law/educarion-programs
- Adilet Constitution (Kazakh): https://old.adilet.zan.kz/kaz/docs/K2600000000
- Adilet Constitution (Russian): https://old.adilet.zan.kz/rus/docs/K2600000000
- Adilet Constitution (English, unofficial translation): https://old.adilet.zan.kz/eng/docs/K2600000000
- University of Messina TELS 2026/27: https://giurisprudenza.unime.it/en/node/903
- Messina official teaching plan 2026–2029: https://giurisprudenza.unime.it/sites/dip04/files/2026-07/Didattica%20programmata%20L-14%20%28TELS%29%202026-2029.pdf
- Tallinn University Law: https://www.tlu.ee/en/yti/law
- Aristotle University of Thessaloniki Law: https://gateway.auth.gr/programmes/law/
- University of Groningen bachelor programmes: https://www.rug.nl/rechten/onderwijs/bachelor/bacheloropleidingen?lang=en
- Cornell LII Wex (contract / consideration / force majeure / indemnity): https://www.law.cornell.edu/wex
- EUR-Lex: https://eur-lex.europa.eu/homepage.html
- UN Treaty Collection: https://treaties.un.org/
- HUDOC: https://hudoc.echr.coe.int/

## Data and integrity

- Cumulative Kazakh law-discipline dataset: 243 rows (242 carried forward + 1 new official title).
- 52-university registry files were not edited.
- Stage 15 files remain preserved; this is a separate Stage 16 working copy.
- GitHub was not changed and nothing was published.
- Visual browser testing was not performed.
- PDF catalogues hosted on `smart.enu.kz` still time out; their full elective-course lists remain unverified.
- The English Europe catalogue is an expanded verified selection, not an exhaustive list of every European programme.

## Scope boundary

This stage advances three workstreams but does not claim that all 52 university programmes and all course catalogues have been exhaustively audited. The next defensible step is to continue university-by-university using official Kazakh source pages and to add discipline titles only where exact source text can be read.
