# EduZan — аудит 25 программ Европы (22 ноября 2026)

## Итог и пределы проверки

В каталоге обнаружено 25 программных карточек в шести странах и отдельном блоке магистратур. В этой итерации сверены официальные страницы и подтверждены отдельные сведения о статусе программ, языке, требованиях и приёме 2027/28. Это НЕ означает, что все 25 программ прошли полную проверку стоимости и дедлайнов: по ряду программ официальные страницы 2027/28 ещё не содержат всех данных или требуют отдельного изучения.

**Важно:** стоимость обучения не унифицирована в карточках. Не переносить цены 2026/27 на 2027/28. Для каждого кандидата стоимость должна сопровождаться годом набора, категорией (EU/non-EU), типом тарифа и ссылкой на официальную страницу.

## Подтверждённые изменения, внесённые в карточки

1. **Maastricht University — European Law School (Bachelor):** на 2027/28 указан numerus fixus; Studielink открыт с 1 октября 2026; полный пакет admission tasks — до 15 января 2027, распределение мест — невзвешенная случайная жеребьёвка. Это ключевое условие, которое нельзя опускать в карточке.
2. **University of Groningen — LL.M. International Commercial Law:** селективная программа; срок для Dutch/EU/EEA/non-EU — 1 мая 2027, начало 1 сентября 2027. Требуется юридическая степень, а также базовые знания европейского и международного публичного права и частного права. Не позиционировать как доступную после обычного неюридического BA.
3. **Maastricht University — International Laws (Master):** селективная программа на 2027/28; среди возможных оснований есть юридические дипломы и некоторые академические степени в смежной области, но решение индивидуальное; для non-EU полный дедлайн — 1 мая 2027. Не обещать допуск выпускнику любой специальности.
4. **Tilburg University — Global Law (LLB):** официальная процедура для иностранных школьных дипломов показывает дедлайн 1 апреля для non-EEA и 1 мая для EEA при августовском старте; для допуска требуется диплом, сопоставимый с Dutch VWO. Проверять конкретную страновую эквивалентность отдельно.
5. **EBS University — BA Law, Politics and Economics:** официальная страница указывает общую стоимость €54,480 за шесть семестров; в предыдущей карточке цена за семестр была указана без достаточного контекста. До публикации уточнить, относится ли тариф к конкретному intake и не изменён ли для 2027/28.
6. **ELTE — European and International Business Law LL.M.:** официальный сайт прямо требует уже имеющуюся юридическую MA-степень или эквивалент и английский B2. Страница содержит внутреннее несоответствие по кредитам: в характеристиках указано 60 ECTS, далее в описании структуры встречается 120 ECTS. В карточке оставить 60 только после письменного/актуального подтверждения программы; в редакторском процессе пометить расхождение.
7. **ELTE — European Human Rights LL.M.:** также требуется юридическая MA-степень/эквивалент и B2; для 2027/28 указаны начало 1 сентября и дедлайн 30 июня 2027. Не рекомендовать как прямой переход после бакалавриата по истории.
8. **ELTE — Law, Politics and Economics MA:** опубликован набор 2027/28; допускаются бакалаврские дипломы в Law, Economics & Business, Social Sciences и Public Administration. Исторический диплом может потребовать индивидуальной классификации как social sciences; не обещать автоматический допуск. Non-EU fee указан €3,500/семестр, EU €1,600/семестр; application fee зависит от периода подачи.
9. **LUISS — Law for Global Challenges:** официальная страница показывает 2027/28, 120 ECTS, два года, английский язык, €16,000 за первый год; программа остаётся subject to Ministry approval and may undergo modifications. Уточнить статус утверждения перед рекомендацией.
10. **Bocconi — Bachelor in Global Law:** официальный каталог подтверждает 3 года, 180 CFU, английский язык. На 2027/28 Global Law указан с 80 местами в классе; tuition и индивидуальные admission details сверять с соответствующим intake.
11. **University of Milan — IPLE:** это междисциплинарный бакалавриат (L-36), не классическая law degree; язык программы английский, но требуется владение ещё одним языком ЕС, включая итальянский для не-носителей. В текущей карточке это условие следует сделать заметным.

## Реестр всех 25 карточек: статус аудита

| № | Программа | Статус в этой итерации |
|---:|---|---|
| 1 | EBS — BA Law, Politics and Economics | Официальная программа и общая стоимость найдены; цену 2027/28 подтвердить |
| 2 | EBS — LL.M. International Law, Politics and Economics | Требуется отдельная проверка действующего набора, degree award и entry requirements |
| 3 | Maastricht — European Law School | 2027/28 приём, numerus fixus, lottery и deadline подтверждены |
| 4 | Tilburg — Global Law (LLB) | 2027/28 admissions deadlines и VWO-equivalence confirmed |
| 5 | Groningen — International and European Law (LLB) | 2027/28: deadline 1 May 2027 for all categories; VWO-equivalent diploma + compulsory matching; tuition €2,771 EU/EEA, €14,400 non-EU/EEA. Does not automatically satisfy Dutch civiel effect. |
| 6 | Maastricht — International Laws (Master) | 2027/28 selective admissions и non-EU deadline подтверждены |
| 7 | Bocconi — Bachelor in Global Law | 2027/28: 80 places per class; tuition €17,700 first year. Tuition waivers exist but are competitive/need-assessed, not guaranteed. |
| 8 | LUISS — Bachelor Global Law | 2027/28: 180 ECTS, English, €15,000 first-year tuition; non-EU certification route deadline 10 Feb 2027 (SAT 1200, LSAT 160, ACT 25, IB 36/45) or Luiss Test 22–26 Feb 2027. |
| 9 | Milan — IPLE | Официальная карточка 2026/27: English, 180 ECTS, 125 + 25 non-EU places, admission test; 2027/28 call ещё проверить. В найденных entry requirements указано English B2; отдельное требование второго языка как условия поступления не подтверждено |
| 10 | Bologna — Legal Studies (LEGS) | Проверить активность набора 2027/28, curriculum и admission prerequisites |
| 11 | ELTE — European and International Business Law LL.M. | Юридическая MA и B2 обязательны; кредитное несоответствие на официальной странице требует уточнения |
| 12 | ELTE — European Human Rights LL.M. | Юридическая MA и B2 обязательны; 2027/28 deadline 30 June подтверждён |
| 13 | ELTE — Law, Politics and Economics MA | 2027/28 опубликован; eligible degree fields, fees and staged application fees найдены |
| 14 | Luxembourg — Bachelor en Droit | FR/EN (около 80% FR / 20% EN); B2 по обоим языкам, numerus clausus; €400/semester и deadlines относятся к 2026/27, 2027/28 не подтверждён |
| 15 | Luxembourg — Master in Legislative Studies | 120 ECTS, FR около 70% / EN около 30%; French C1 + English B2; подходящие предыдущие степени включают contemporary political history и social sciences; 2026 deadlines/€750 per semester, цикл 2027/28 отдельно подтвердить |
| 16 | Malta — LL.M. European and Comparative Law | English, 90 ECTS; основной вход — law degree/Doctor of Laws или эквивалент; board may consider European Studies, Political Science, Economics и иные подходящие области. Non-EU fee €10,800 на карточке 2026/27; новый цикл проверить |
| 17 | Malta — LL.M. European Business Law | English, 90 ECTS, full-time 3 semesters; law degree/Doctor of Laws или эквивалент. Non-EU fee €10,800 на карточке 2026/27; 2027/28 не подтверждён |
| 18 | Malta — Master in Financial Services | M.A., не LL.M.; 2027/28 карточка опубликована: 90 ECTS, 3 semesters, English, non-EU €10,800. Допустимые области включают Law, Accountancy, Banking and Finance, Economics, Insurance; другие релевантные квалификации — индивидуально/возможное интервью |
| 19 | Groningen — LL.M. International Commercial Law | Селективный; юридическая степень, subject knowledge, deadline 1 May 2027 подтверждены |
| 20 | Tilburg — LL.M. International and European Law | 60 ECTS/1 year; law, political science, IR, European Studies or law-related degree (30 ECTS law); different degree may be considered case-by-case with evidence of relevant skills/experience. Non-EEA deadlines: 1 Apr (Aug start), 1 Oct (Jan start). |
| 21 | Tilburg — LL.M. International Business Law: Digital Innovation in Commerce and Finance | 60 ECTS/1 year; requires Law degree or law-related degree with at least 90 ECTS in law; non-EEA deadline 1 Apr. A History BA without substantial law coursework does not meet standard published requirement. |
| 22 | Bologna — LL.M. Legal Studies (LEGS) | 2026/27 карточка имеется; 2027/28 активность и curriculum нужно обновить |
| 23 | Bologna — Law, Economics and Governance | 2026/27 catalogue; English, 120 ECTS; degree classes include LM-56 Economics and LM/SC-GIUR, confirming interdisciplinary economics-law status. From 2027/28 OOPT will no longer be accepted for B2 proof; verify current call and alternative certificates. |
| 24 | LUISS — Master of Law in European Law and Policies | 2026/27 call: 60 ECTS, 12 months, €9,500, four/five-year degree; LL.M. title requires prior law undergraduate degree. 2027/28 call not confirmed on programme page |
| 25 | LUISS — Law for Global Challenges | 2027/28: 120 ECTS, 2 years, English, €16,000/year; subject to Ministry approval |

## Особо важные рекомендации для профиля с бакалавриатом по истории

- Не считать ELTE European and International Business Law LL.M. и ELTE European Human Rights LL.M. прямыми вариантами: оба требуют юридическую MA/эквивалент.
- Groningen International Commercial Law LL.M. также требует юридическую степень и базовые знания права; обычный History BA не удовлетворяет базовому требованию автоматически.
- Maastricht International Laws заслуживает индивидуального рассмотрения: допускается рассмотрение некоторых related academic degrees, но программа selective и не гарантирует приём.
- ELTE Law, Politics and Economics MA может быть более реалистичным междисциплинарным вариантом, если вуз признает History как соответствующее направление Social Sciences.
- Для программ в Италии различать `Laurea Magistrale`/профессиональный юридический путь и англоязычные interdisciplinary degrees. Нельзя обещать право на адвокатскую практику по факту наличия английского BA/MA.

## Официальные источники, использованные в этой итерации

- Maastricht European Law School 2027/28 admissions: https://www.maastrichtuniversity.nl/education/bachelor/programmes/european-law-school/admission-requirements
- Maastricht International Laws 2027/28 admissions: https://www.maastrichtuniversity.nl/education/master/programmes/international-laws/admission-requirements
- Groningen International Commercial Law: https://www.rug.nl/masters/international-commercial-law/?lang=en
- Groningen LLM general admission requirements: https://www.rug.nl/rechten/education/english-taught-programmes/llm/application/admission-requirements?lang=en
- Tilburg Global Law admission: https://www.tilburguniversity.edu/education/bachelors-programs/global-law/application
- EBS BA programme: https://www.ebs.edu/en/ebs-law-school/bachelor-in-law-politics-and-economics
- ELTE Business Law LL.M.: https://www.elte.hu/en/european-and-international-business-law-llm
- ELTE Human Rights LL.M.: https://www.elte.hu/en/european-human-rights-llm
- ELTE Law, Politics and Economics MA: https://www.elte.hu/en/law-politics-and-economics-ma
- LUISS Global Law: https://www.luiss.it/en/courses-and-masters-programmes/undergraduate-school/global-law
- LUISS Law for Global Challenges: https://www.luiss.it/en/courses-and-masters-programmes/graduate-school/law-global-challenges
- Bocconi Global Law: https://www.unibocconi.it/en/programs/law/bachelor-global-law
- Milan IPLE: https://www.unimi.it/en/education/bachelor/international-politics-law-and-economics-iple


## Дополнительная официальная проверка: Мальта, Люксембург, Милан и LUISS (22.11.2026)

### University of Malta
- **LL.M. European and Comparative Law:** 90 ECTS; full-time и part-time. Основное требование — Doctor of Laws либо Bachelor in Law как основная область (минимум Second Class Honours/Category II), либо эквивалент, признанный Board. Board может рассмотреть European Studies, Political Science, Economics и другие подходящие направления — это дискреционное решение, не гарантированный допуск. На доступной карточке 2026/27 для non-EU указано €10,800.
- **LL.M. European Business Law:** 90 ECTS; full-time три семестра, также part-time. Требуется юридическая степень или признанный эквивалент. Не обозначать как открытый всем non-law выпускникам. На доступной карточке 2026/27 non-EU fee €10,800.
- **Master in Financial Services:** это M.A., не LL.M.; 90 ECTS, три семестра, английский, full-time evening / part-time. На официальной странице 2027/28 перечислены Law, Accountancy, Banking and Finance, Economics, Insurance; другие релевантные квалификации могут быть рассмотрены индивидуально, возможно интервью. Non-EU fee на карточке 2027/28 — €10,800. Для заявителей с дипломом истории это не автоматический допуск, но возможна индивидуальная оценка релевантности.

### University of Luxembourg
- **Bachelor en Droit:** французский и английский (примерно 80/20); B2 по обоим языкам, признанный школьный диплом, numerus clausus. 2026/27 fee €400/semester; не переносить на 2027/28 без новой страницы.
- **Master in Legislative Studies:** 120 ECTS; французский около 70%, английский около 30%; French C1 + English B2. Требуемые направления включают public administration, law, contemporary political history, international relations, philosophy, political science, economics и social sciences. Это междисциплинарная, не юридическая степень; выпускник истории может соответствовать предметному профилю, если университет признает диплом и выполнены языковые требования. Дедлайны 2026 и €750/semester — данные старого цикла, не подтверждение 2027/28.

### University of Milan — IPLE
Официальная карточка, найденная при проверке, относится к 2026/27: Bachelor, 180 ECTS, English, limited enrolment; 125 мест плюс 25 для non-EU applicants residing abroad, admission test. На странице указано English B2. Отдельное требование второго языка ЕС как входное условие в текущих entry requirements не подтверждено; не включать это утверждение в карточку без отдельного официального подтверждения. Даты приёма 2026 года не переносить на 2027/28.

### LUISS School of Law — European Law and Policies
Доступная страница содержит call 2026/27: 60 ECTS, 12 месяцев, английский, четыре- или пятилетний диплом, €9,500, deadline 30 September 2026. Для финального обозначения LL.M. требуется предыдущий undergraduate degree in Law. На 22.11.2026 отдельный call 2027/28 на этой странице не подтверждён; стоимость и сроки следующего цикла не указывать как установленные.

## Дополнительные официальные источники
- University of Malta, LL.M. European and Comparative Law: https://www.um.edu.mt/courses/overview/pmleclpdt0-2026-7-o/
- University of Malta, LL.M. European Business Law: https://www.um.edu.mt/courses/overview/pmleubftt5-2026-7-o/
- University of Malta, M.A. Financial Services 2027/28: https://www.um.edu.mt/courses/overview/pmafnsfet8-2027-8-o/
- University of Luxembourg, Bachelor en Droit admissions: https://www.uni.lu/fdef-en/study-programs/bachelor-en-droit/admissions/
- University of Luxembourg, Master in Legislative Studies admissions: https://www.uni.lu/fhse-en/study-programs/master-in-legislative-studies/admissions/
- University of Luxembourg, Master in Legislative Studies programme: https://www.uni.lu/fhse-en/study-programs/master-in-legislative-studies/programme/
- University of Milan, IPLE: https://www.unimi.it/en/education/bachelor/international-politics-law-and-economics-iple
- LUISS School of Law, European Law and Policies admission: https://lsl.luiss.it/european-law-and-policies-melp/admission


### Дополнительная проверка Tilburg University и University of Bologna
- **Tilburg — LL.M. International and European Law:** 60 ECTS, one year, start late August or late January. Standard eligible backgrounds include Law, Political Science/Politics, International Relations, European Studies, or law-related degree with at least 30 ECTS law. Applicants with a different academic background may be considered case-by-case if they demonstrate relevant abilities (e.g. 30 ECTS law courses, relevant internship or work experience). Non-EEA deadlines: 1 April for August start and 1 October for January start. This is a possible, but not guaranteed, route for a non-law graduate.
- **Tilburg — LL.M. International Business Law: Digital Innovation in Commerce and Finance:** 60 ECTS, one year, August start; online-only and on-campus formats. Entry requires a Law bachelor or a law-related bachelor with at least 90 ECTS in law courses. A History BA without substantial legal coursework does not meet the standard published criterion. Non-EEA deadline: 1 April.
- **Bologna — Law, Economics and Governance:** English-taught 120 ECTS Laurea Magistrale. Official degree classification includes LM-56 (Economics) and LM/SC-GIUR, so this is an interdisciplinary economics-law degree, not a conventional LL.M. From 2027/28 the University states that its OOPT language test will no longer be accepted as proof of B2 English; applicants must use another accepted certificate and check the new call.

Official sources: https://www.tilburguniversity.edu/education/masters-programs/international-and-european-law/application ; https://www.tilburguniversity.edu/education/masters-programs/international-business-law/application ; https://www.corsi.unibo.it/2cycle/LawEconomicsGovernance/how-to-enrol ; https://www.unibo.it/en/study/second-cycle-degree/programme/2026/6829


### Дополнительная проверка бакалавриатов Нидерландов и Италии
- **Groningen — International and European Law (LLB):** на 2027/28 опубликованы дедлайн 1 May 2027 для Dutch/EU/EEA/non-EU и старт 1 September 2027; нужен школьный диплом, эквивалентный Dutch VWO, и обязательное matching activity. Плата 2027/28: €2,771 EU/EEA и €14,400 non-EU/EEA. Программа не даёт автоматического civiel effect.
- **Bocconi — Bachelor in Global Law:** 3 года, English, 180 CFU; на 2027/28 — 80 мест в классе и €17,700 tuition для первого года. Есть tuition waivers и need-based support, но они не гарантированы и зависят от оценки заявки и доступного финансирования.
- **LUISS — Global Law:** 3 года, 180 ECTS, English; 2027/28 first-year fee €15,000. Для non-EU/extra-Schengen опубликованы маршруты Luiss Test и международных сертификатов; в certification route принимаются, среди прочего, SAT ≥1200, LSAT ≥160, ACT ≥25, IB ≥36/45; deadline 10 February 2027. Luiss Test проводится 22–26 February 2027.

Official sources: https://www.rug.nl/bachelors/international-and-european-law/?lang=en ; https://www.rug.nl/rechten/education/english-taught-programmes/llb/application/admission-requirements?lang=en ; https://www.unibocconi.it/en/applying-bocconi/bachelor-and-law-programs/fees ; https://www.unibocconi.it/en/applying-bocconi/bachelor-and-law-programs/application-and-admissions/admissions ; https://www.luiss.it/en/courses-and-masters-programmes/undergraduate-school/global-law ; https://www.luiss.it/en/guidance-and-admissions/admissions-procedures/admissions-to-undergraduate-and-single-cycle-law-degrees/non-eu-schengen-students/direct-admissions-with-qualifications-to-undergraduate-and-master%27s-degree-programmes-non-eu-students

## Пределы

Это редакторский аудит по состоянию на 22.11.2026, а не решение приёмной комиссии. Для оставшихся карточек нужно отдельно открыть соответствующий официальный call/admission page 2027/28, сверить стоимость по non-EU категории, наличие мест и конкретные требования к предыдущему диплому. Нельзя помечать каталог как полностью verified до завершения этих проверок.


## Повторная контрольная сверка официальных страниц (22 ноября 2026)

В дополнительной проверке выявлены две существенные редакционные ошибки/неопределённости, исправленные в карточках:

1. **Bocconi — Bachelor in Global Law:** официальная страница admissions для 2027/28 подтверждает 80 мест в классе Global Law, но прямо сообщает, что плата за 2027/28 будет объявлена позднее. Около €17,000 — ориентир по 2026/27, а не подтверждённая цена 2027/28. Утверждение о €17,700 для нового цикла удалено. Источники: https://www.unibocconi.it/en/applying-bocconi/bachelor-and-law-programs/application-and-admissions/admissions ; https://www.unibocconi.it/en/applying-bocconi/bachelor-and-law-programs

2. **ELTE — European and International Business Law LL.M.:** официальная страница содержит внутреннее расхождение: в кратких характеристиках указано 60 ECTS, однако в описании структуры сказано о 60 кредитах за каждый семестр и 120 ECTS в сумме. Карточка больше не утверждает однозначно 60 ECTS; объём помечен как требующий письменного уточнения у университета. Источник: https://www.elte.hu/en/european-and-international-business-law-llm

Дополнительно перепроверены следующие данные:
- Maastricht International Laws: на странице для 2027/28 указаны сроки 1 мая 2027 для большинства non-EU/EEA заявителей и 1 июня 2027 для EU/EEA/Swiss; программа селективная, admission зависит от предыдущего образования и индивидуальной оценки. https://www.maastrichtuniversity.nl/education/master/programmes/international-laws/admission-requirements
- Groningen International and European Law LLB: подтверждены тарифы 2027/28 €2,771 EU/EEA и €14,400 non-EU/EEA; дедлайн 1 мая 2027. https://www.rug.nl/bachelors/international-and-european-law/?lang=en ; https://www.rug.nl/rechten/onderwijs/praktische-informatie/toelating-en-aanmelding/stappen?lang=en
- Groningen International Commercial Law LL.M.: дедлайн 1 мая 2027 для Dutch/EU/EEA/non-EU/EEA; селективный набор, базовые знания европейского и международного публичного права и частного права. Тариф, отображённый на странице, относится к 2026/27 и не должен переноситься на 2027/28. https://www.rug.nl/masters/international-commercial-law/?lang=en
- Tilburg International and European Law LL.M.: 60 ECTS, один год; стандартные профили включают Law, Political Science/IR, European Studies, law-related degree с минимум 30 ECTS права; другой диплом может рассматриваться индивидуально при доказанных релевантных навыках/опыте. Non-EEA сроки — 1 апреля для августовского старта и 1 октября для январского. https://www.tilburguniversity.edu/education/masters-programs/international-and-european-law/application
- Tilburg International Business Law: Digital Innovation in Commerce and Finance LL.M.: 60 ECTS; требуется диплом Law либо law-related degree с минимум 90 ECTS юридических дисциплин; non-EEA deadline — 1 апреля. https://www.tilburguniversity.edu/education/masters-programs/international-business-law/application
- LUISS Global Law Bachelor: 2027/28, 180 ECTS, English, €15,000 tuition for year one. https://www.luiss.it/en/courses-and-masters-programmes/undergraduate-school/global-law
- LUISS Law for Global Challenges: 2027/28, 120 ECTS, 2 years, English, €16,000 for year one; remains subject to Ministry approval. https://www.luiss.it/en/courses-and-masters-programmes/graduate-school/law-global-challenges
- ELTE Law, Politics and Economics MA: 2027/28 intake confirmed, fees €1,600/semester EU/EEA and €3,500/semester non-EU/EEA; accepted degree fields include Law, Economics & Business, Social Sciences and Public Administration. https://www.elte.hu/en/law-politics-and-economics-ma
- University of Luxembourg Bachelor en Droit: admissions page currently displays 2026/27 deadlines and €400/semester; do not represent these as 2027/28 terms. English and French B2 are required. https://www.uni.lu/fdef-en/study-programs/bachelor-en-droit/admissions/
- University of Bologna Legal Studies: official catalogue currently retrieved for 2026/27, confirms English, two years and 150 places; 2027/28 call not yet confirmed in this review. https://dsg.unibo.it/en/study/degree?set_language=en

## Ограничения контрольной сверки

Это не означает, что все 25 карточек имеют подтверждённые на 2027/28 цены и дедлайны. По программам, для которых университет пока публикует только 2026/27 данные, сохранена явная оговорка. В ряде карточек требуется ещё проверить стоимость и полный набор admission criteria по отдельным официальным страницам. Перед публикацией каждой цены необходимо указывать учебный год, категорию заявителя и валюту.
