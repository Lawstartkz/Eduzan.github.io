# EduZan — Stage 18: европейский каталог и практический Legal English

## Что сделано

1. Каталог `law-in-europe.html` расширен с 10 до 11 стран: добавлена Польша и официально подтверждённая программа Adam Mickiewicz University — **Bachelor of Arts in European Legal Studies**. Программа отмечена как **Law-related Degree**, а не LL.B. Университет указывает 3 года, английский язык и профессиональное звание `licencjat`.
2. Для AMU добавлены ограничения и контекст набора: каталог 2026/27 указывает English B2, плату 3 500 PLN за семестр на первом курсе и завершённый цикл приёма; учебный план проходит комплексное обновление. Указано, что отдельным иностранным кандидатам может потребоваться вступительный экзамен. Данные следующего цикла не придуманы.
3. Обновлена карточка Maastricht University **European Law School**: 3 года / 180 ECTS / English; 2027/28 numerus fixus и дедлайн 15 января 2027 года; случайное распределение мест; главное — университет прямо определяет степень как non-qualifying law degree. Добавлено пояснение национального нидерландского маршрута через переход в нидерландоязычную Rechtsgeleerdheid и последующую Dutch Law master’s degree.
4. Казахская версия каталога `kz/kz-law-in-europe.html` синхронизирована по странам: добавлены Эстония, Греция, Латвия, Кипр и Польша; названия иностранных программ и официальные названия степеней оставлены на языке источника. Описания на казахском являются редакционным переводом проверенных фактов; они не выдаются за официальные казахские версии университетов.
5. В `legal-english.html` добавлен практический блок **Case briefing lab**: структура case brief, IRAC, полезные языковые формулы и задание на 120–160 слов + короткий IRAC-анализ.
6. Параллельный казахский блок добавлен в `kz/kz-legal-english.html`; термины Facts, Issue, Holding, Reasoning, Disposition и IRAC сохранены на английском, пояснения даны на казахском.
7. Добавлен отдельный реестр из 8 официальных источников.

## Основные официальные источники

- Maastricht University — programme/admission: https://www.maastrichtuniversity.nl/education/bachelor/programmes/european-law-school/admission-requirements
- Maastricht University — career and professional qualification: https://www.maastrichtuniversity.nl/education/bachelor/programmes/european-law-school/your-future
- Maastricht University — bachelor FAQ (180 ECTS): https://www.maastrichtuniversity.nl/new-b/european-law-school-bachelor-faq
- Adam Mickiewicz University — BA European Legal Studies: https://amu.edu.pl/en/admissions/bachelor-degree-programs/bachelor-of-arts-in-european-legal-studies
- AMU recruitment catalogue 2026/27: https://rekrutacja.amu.edu.pl/en/studies-cataloge/european-legal-studies,429
- AMU Faculty programme page: https://legalstudies.amu.edu.pl/european-legal-studies/
- University of Wisconsin Law School — Case Briefing Guide: https://law.wisc.edu/orientation/casebriefingguide.pdf
- Cornell LII — Legal Writing: https://www.law.cornell.edu/wex/Legal_writing
- Cornell LII — FRAP Rule 28: https://www.law.cornell.edu/rules/frap/rule_28

## Важные оговорки

- AMU сообщает, что программа European Legal Studies проходит комплексное обновление; детали старого учебного плана не представлены как гарантированный окончательный план следующего набора.
- BA European Legal Studies в AMU не назван LL.B.; каталог не представляет его как автоматическую квалификацию для адвокатской практики.
- Maastricht European Law School не даёт автоматического допуска к профессиям адвоката, прокурора или судьи.
- IRAC и case brief — учебные методики, а не единый обязательный формат для всех правовых систем. FRAP Rule 28 относится к апелляционным brief в США и не переносится автоматически на другие юрисдикции.
- Казахские пояснения иностранных программ — редакционные переводы фактов из официальных англоязычных источников; оригинальные названия программ/степеней сохранены.

## Проверка и сохранность проекта

- Проверены HTML-структура, уникальность ID и внутренние якоря для четырёх изменённых страниц.
- Проверена целостность ZIP.
- Три файла реестра 52 университетов сравниваются с Stage 17 и должны остаться побайтно неизменными.
- Кумулятивный реестр казахских юридических дисциплин перенесён из Stage 17 без изменения; новых названий дисциплин в этом этапе не добавлялось.
- GitHub не изменялся; публикация и push не выполнялись.
- Браузерное визуальное тестирование не выполнялось.
